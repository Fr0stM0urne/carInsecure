#ifndef __CAR_SECRETS__
#define __CAR_SECRETS__

#define CAR_SECRET 70

#define CAR_ID "69"

#define PASSWORD "unlock"

#endif
